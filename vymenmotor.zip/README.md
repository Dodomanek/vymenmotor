
# Vymenmotor Landing Page

Toto je skeleton projektu pro GitHub Pages.

## Jak spustit

```bash
pnpm install
pnpm build
```

Složka `dist/` nahraje GitHub Actions workflow.
